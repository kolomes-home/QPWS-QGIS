The following fonts were updated to include the new point symbols and need to be installed for the .style and .stylx files to work and read correctly:

AAHS INCIDENTS.ttf
AAHS_OPERATIONS.ttf
AAHS OBSERVATION.ttf

The remaining fonts are required to be installed for the .style and .stylx files to work and read correctly, however these were not updated.  These fonts are:

AAHS ASSETS.ttf
AAHS FIRE.ttf
AAHS SES.TTF
Hazard_Icons.ttf
